-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2023 at 10:53 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `vacaciones`
--

CREATE TABLE `vacaciones` (
  `id` int(11) NOT NULL,
  `empleado` varchar(255) NOT NULL,
  `fecha_contratacion` date NOT NULL,
  `periodo_2017` date NOT NULL,
  `periodo_2018` date NOT NULL,
  `periodo_2019` date NOT NULL,
  `periodo_2020` date NOT NULL,
  `periodo_2021` date NOT NULL,
  `periodo_2022` date NOT NULL,
  `periodo_2023` date NOT NULL,
  `periodo_2024` date NOT NULL,
  `periodo_2025` date NOT NULL,
  `dias_solicitados` int(255) NOT NULL,
  `dias_totales` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vacaciones`
--

INSERT INTO `vacaciones` (`id`, `empleado`, `fecha_contratacion`, `periodo_2017`, `periodo_2018`, `periodo_2019`, `periodo_2020`, `periodo_2021`, `periodo_2022`, `periodo_2023`, `periodo_2024`, `periodo_2025`, `dias_solicitados`, `dias_totales`) VALUES
(1, 'JUAN CARLOS MARIN QUISABONI', '2022-10-24', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0),
(2, 'JUAN CARLOS MARIN QUISABONI', '2023-01-01', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 5, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vacaciones`
--
ALTER TABLE `vacaciones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vacaciones`
--
ALTER TABLE `vacaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
